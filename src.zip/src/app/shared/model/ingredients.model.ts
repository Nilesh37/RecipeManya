export class Ingredients{
    constructor(
        public ingName :string,
        public ingBrand :  string,
        public ingQty: number|string
    ){
    }
}